import { Metadata } from "next";
import { Header } from "@/components/layout/header";
import { CvStoreHydrator } from "@/lib/store/hydrate";

export const metadata: Metadata = {
  title: "CV Builder | CvCRAFT",
  description: "Create and edit your professional CV",
};

export default function BuilderLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <CvStoreHydrator />
      <Header />
      <main className="flex-grow">
        {children}
      </main>
    </div>
  );
}
